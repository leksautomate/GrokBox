$root = "c:\Users\leksi\Desktop\Project\grok"
$zipPath = "$root\GrokBox.zip"
$tempDir = "$root\GrokBox_temp"

# Clean up
if (Test-Path $zipPath) { Remove-Item $zipPath }
if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }

# Create temp structure
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
New-Item -ItemType Directory -Path "$tempDir\icons" -Force | Out-Null

# Copy extension files
Copy-Item "$root\manifest.json" -Destination $tempDir
Copy-Item "$root\background.js" -Destination $tempDir
Copy-Item "$root\content.js" -Destination $tempDir
Copy-Item "$root\content.css" -Destination $tempDir
Copy-Item "$root\sidepanel.html" -Destination $tempDir
Copy-Item "$root\sidepanel.js" -Destination $tempDir
Copy-Item "$root\icons\icon16.png" -Destination "$tempDir\icons"
Copy-Item "$root\icons\icon48.png" -Destination "$tempDir\icons"
Copy-Item "$root\icons\icon128.png" -Destination "$tempDir\icons"

# Create zip from contents
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath

# Clean up temp
Remove-Item $tempDir -Recurse -Force

Write-Host "Created $zipPath"
Get-Item $zipPath | Select-Object Name, Length
